eWEEK Openhack 4 application
============================

July 1, 2002

Database Build Scripts
======================
The database build scripts can be found in the database directory. Run the scripts in
the following order in SQL Plus:

1. create.sql
2. createtrg.sql
3. EDPP001_denc1.sql
4. EDPP001_enc.sql
5. awards_db_base_data.sql


OpenHack Application
======================
This is contained in the openhackapp directory. 
